package com.pimatech.holedistance.engine
import java.math.BigDecimal
import org.junit.Test
import org.junit.Assert.*
import kotlin.random.Random
class HoleDistanceTest {
 private fun d(s:String)=BigDecimal(s)
 private fun eq(expected:String,actual:BigDecimal)=assertEquals(0,d(expected).compareTo(actual))
 @Test fun outsideEqualAndNominal() {
  val a=Hole(d(".5"),d(".501"))
  val r=HoleDistance.solve(d("2"),a,a,d("2.502"),SpanKind.OUTSIDE)
  eq("2.001",r.center);eq(".001",r.deviation);eq("2.501",r.requiredSpan);eq("2.5",r.nominalSpan);eq("1.5",r.inside);eq("2.501",r.targetOutside);eq("1.499",r.targetInside)
 }
 @Test fun insideUnequalAndUnder() {
  val r=HoleDistance.solve(d("3"),Hole(d(".5"),d(".502")),Hole(d(".25"),d(".248")),d("2.624"),SpanKind.INSIDE)
  eq("2.999",r.center);eq("-.001",r.deviation);eq("2.625",r.requiredSpan);eq("2.625",r.nominalSpan);eq("3.374",r.outside)
 }
 @Test fun tangentAndExactDecimal() {
  val a=Hole(d(".000000000001"),d(".000000000003"))
  val b=Hole(d(".000000000002"),d(".000000000004"))
  val r=HoleDistance.solve(d(".0000000000035"),a,b,BigDecimal.ZERO,SpanKind.INSIDE)
  eq(".0000000000035",r.center);eq("0",r.deviation)
  eq(".000000000007",r.outside);eq(".000000000002",r.nominalSpan)
 }
 @Test fun rejectsImpossibleInputs() {
  val a=Hole(d(".5"),d(".5"))
  fun bad(target:String="2",hole:Hole=a,span:String="2.5",kind:SpanKind=SpanKind.OUTSIDE) {
   assertThrows(IllegalArgumentException::class.java){HoleDistance.solve(d(target),hole,a,d(span),kind)}
  }
  bad(target="0");bad(hole=Hole(d("0"),d(".5")));bad(hole=Hole(d(".5"),d("-.1")))
  bad(target=".4");bad(span=".9");bad(span="-1",kind=SpanKind.INSIDE)
  bad(target="1000001");bad(span="3000001");bad(hole=Hole(d("1000001"),d(".5")))
  bad(target=".6",hole=Hole(d("1"),d(".5")));bad(target=".6",hole=Hole(d(".5"),d("1")))
 }
 @Test fun coordinatesOracleAndModeEquivalence() {
  val random=Random(27)
  repeat(500) {
   // Independent coordinate oracle: form wall positions from two known centers.
   val radius1=BigDecimal(random.nextInt(1,10000)).movePointLeft(4)
   val radius2=BigDecimal(random.nextInt(1,10000)).movePointLeft(4)
   val leftCenter=BigDecimal(random.nextInt(-100000,100000)).movePointLeft(4)
   val knownCenter=radius1.add(radius2).add(BigDecimal(random.nextInt(0,100000)).movePointLeft(4))
   val rightCenter=leftCenter.add(knownCenter)
   val farLeft=leftCenter.subtract(radius1);val farRight=rightCenter.add(radius2)
   val nearLeft=leftCenter.add(radius1);val nearRight=rightCenter.subtract(radius2)
   val a=Hole(radius1.multiply(d("2")),radius1.multiply(d("2")))
   val b=Hole(radius2.multiply(d("2")),radius2.multiply(d("2")))
   val outside=HoleDistance.solve(knownCenter,a,b,farRight.subtract(farLeft),SpanKind.OUTSIDE)
   val inside=HoleDistance.solve(knownCenter,a,b,nearRight.subtract(nearLeft),SpanKind.INSIDE)
   assertEquals(0,knownCenter.compareTo(outside.center));assertEquals(0,knownCenter.compareTo(inside.center))
   assertEquals(0,outside.center.compareTo(HoleDistance.solve(knownCenter,a,b,outside.inside,SpanKind.INSIDE).center))
  }
 }
 @Test fun unitsAndSubResolutionSigns() {
  eq("25.4",LengthUnit.INCH.canonical(d("1")))
  eq(".5",LengthUnit.INCH.display(d("12.7")))
  assertEquals("+<0.000001 in",formatDimension(d(".0000000001"),LengthUnit.INCH,true))
  assertEquals("−<0.00001 mm",formatDimension(d("-.0000000001"),LengthUnit.MM,true))
  assertEquals("0.000000 in",formatDimension(BigDecimal.ZERO,LengthUnit.INCH,true))
 }
}
