# Engineering notes

All stored physical lengths are decimal millimeters (`BigDecimal`). Inch inputs multiply by exact 25.4; unit switches only change presentation and never rewrite lengths. Display conversion divides by 25.4 to 16 decimal places; committing a displayed conversion can introduce a sub-resolution rounding change. Ordinary switching does not.

Calculation uses exact decimal addition, subtraction and division by two. Diameter averaging, the sign of center deviation and span conversion use full stored values, independent of rounded display. Inch displays use six decimal places; metric displays use five, rounded half up. A nonzero value below display resolution is explicitly shown as `<` the resolution, retaining its sign for deviations; it is not shown as exact zero.

The keypad permits positive dimensions up to 12 decimal places; span also permits zero. Targets and diameters are capped at 1,000,000 mm; measured spans at 3,000,000 mm. The calculator rejects nonpositive diameters, nonpositive target centers, negative span and overlapping-hole geometries. It validates both nominal diameters and measured diameters at target centers. If validation fails, calculated results are hidden and the specific input problem is shown.

An outside measurement must span two complete separate holes: M ≥ measured diameter 1 + measured diameter 2. Equality is tangency. For inside measurements M ≥ 0 ensures separation. The target must likewise be at least the sum of the respective radii. Because a single target is compared against both measured and nominal geometry, an impossible target suppresses the answer until corrected.

Same size mode links both target diameters and both measured diameters. Different sizes makes Hole 2 independently editable. Returning to Same size immediately copies Hole 1 values to Hole 2; this is documented in Help. A valid switch of Outside/Inside uses the equivalent span from the current answer to preserve physical center distance. Invalid input remains for correction on a mode change.

All state saves through Android SharedPreferences. No network permission or external service is used. Android resource backup and extraction are disabled. Dialogs use the same native Compose numerical keypad, panels, colors and attribution as the earlier PimaTech calculators.

The diagram deliberately uses illustrative radii and separation to keep both holes and the selected wall contacts legible. It is labeled schematic in the expanded view and is never used for numerical calculations. The app cannot distinguish geometric errors such as offset chords from correct centerline measurements; operators must establish the measurement geometry.

Version 1.0.1: both diagram span labels now display calculated spans at the TARGET center distance using ACTUAL measured diameters. They are independent of the measured span input. Green C continues to show the actual center distance inferred from that input; the header explicitly identifies target-based spans. Both labeled values are exposed in accessibility semantics.
