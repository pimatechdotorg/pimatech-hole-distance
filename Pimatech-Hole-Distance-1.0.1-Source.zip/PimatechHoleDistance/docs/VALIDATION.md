# Validation — 1.0.1 development preview

Validated 2026-10-27, using JDK 17, SDK 35, Build Tools 35.0.0, Gradle 8.9, AGP 8.7.3 and Kotlin 2.0.21.

- Complete build: `:engine:test :app:assembleDebug :app:lintDebug :app:testDebugUnitTest`, BUILD SUCCESSFUL in 1m 1s.
- Six numerical test groups passed. Includes 500 independent coordinate-oracle cases, equal / unequal diameters, inside / outside measurements, positive / negative deviation, nominal-versus-measured distinction, tangency, tiny exact decimals, physical impossibility, range rejection and sub-resolution sign handling.
- Five host-side Android UI tests passed under Robolectric 4.14.1, API 28, native graphics. Verified keypad entry/cancel, independent Hole 2 values, target-based Outside/Inside diagram labels for equal and unequal diameters, linking back to Same size, inside/outside conversion, error output replacing stale results, units, detail dialog, saved state after Activity recreation and 320 × 480 dp control accessibility.
- Native rendered views inspected at 411 × 731 dp: default, inside measurement, different sizes, invalid span and detail dialog. Proof PNGs and test XML are included.
- Android lint: 0 errors, 0 warnings.
- APK manifest verified: separate package `com.pimatech.holedistance`, version 1.0.1 / code 2, Android 8+ (min API 26), target API 35. No Internet permission. Only AndroidX app-specific signature receiver permission is present.
- APK v2 signature verified. Development certificate SHA256: `10554df2fccdf22eeef161d646f2acb8d3d194bd90961e307b0a19745da37d84`.

APK SHA256: `03feb6aba96256b47946f3a0c4f52e6716eabaf40f49c0508da0b19ccee461cc`.

The APK has not been installed and tested against physical measured parts by the developer. It remains a development preview for owner review. Tests do not establish instrument accuracy or certify a measurement method.
