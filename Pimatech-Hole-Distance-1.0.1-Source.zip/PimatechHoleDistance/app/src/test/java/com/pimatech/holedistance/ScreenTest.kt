package com.pimatech.holedistance
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],qualifiers="w411dp-h731dp-port")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class ScreenTest {
 @get:Rule val rule=createAndroidComposeRule<MainActivity>()
 private fun enter(label:String,value:String) {
  rule.onNodeWithText(label).performClick()
  value.forEach{rule.onNodeWithText(it.toString()).performClick()}
  rule.onNodeWithText("Save").performClick()
 }
 private fun shot(name:String,dialog:Boolean=false) {rule.runOnIdle {
  val view=if(dialog) org.robolectric.shadows.ShadowDialog.getLatestDialog().window!!.decorView else rule.activity.window.decorView
  val bitmap=Bitmap.createBitmap(view.width,view.height,Bitmap.Config.ARGB_8888)
  view.draw(Canvas(bitmap));val file=File("build/ui-proof/"+name+".png");file.parentFile!!.mkdirs();file.outputStream().use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}
 }}
 @Test fun defaultAndModeConversion() {
  rule.onNodeWithText("2.001000 in").assertIsDisplayed()
  rule.onNodeWithText("Proudly made and released open source by PimaTech.org").assertIsDisplayed()
  rule.onNodeWithContentDescription("Outside at target centers using actual diameters: 2.501000 in. Inside at target centers using actual diameters: 1.499000 in.",substring=true).assertIsDisplayed()
  shot("default")
  rule.onNodeWithText("Inside gap").performClick()
  rule.onNodeWithText("1.500000 in").assertIsDisplayed()
  rule.onNodeWithText("2.001000 in").assertIsDisplayed()
  shot("inside")
  rule.onNodeWithText("Outside span").performClick()
  rule.onNodeWithText("2.502000 in").assertIsDisplayed()
  rule.onNodeWithText("Span at target centers: 2.501000 in").assertIsDisplayed()
 }
 @Test fun independentDiametersAndLinking() {
  rule.onNodeWithText("Different sizes").performClick()
  enter("Hole 2 target Ø",".25")
  enter("Hole 2 measured Ø",".249")
  rule.onNodeWithText("2.127000 in").assertIsDisplayed()
  rule.onNodeWithText("Hole 1 target Ø").assertIsDisplayed()
  rule.onNodeWithContentDescription("Outside at target centers using actual diameters: 2.375000 in. Inside at target centers using actual diameters: 1.625000 in.",substring=true).assertIsDisplayed()
  shot("different")
  rule.activityRule.scenario.recreate()
  rule.onNodeWithText("0.249000 in").assertIsDisplayed()
  rule.onNodeWithText("Same size").performClick()
  rule.onNodeWithText("Both holes measured Ø").assertIsDisplayed()
  rule.onNodeWithText("2.001000 in").assertIsDisplayed()
  rule.onNodeWithText("Different sizes").performClick()
  rule.onAllNodesWithText("0.501000 in").assertCountEquals(2)
 }
 @Test fun invalidInputAndKeypadCancel() {
  enter("Measured outside span · M",".9")
  rule.onNodeWithText("2.001000 in").assertDoesNotExist()
  rule.onNodeWithText("Outside span is too small for two separate holes. Check the diameters or select Inside gap.").assertIsDisplayed()
  shot("invalid")
  rule.onNodeWithText("Measured outside span · M").performClick()
  rule.onNodeWithText("0").performClick()
  rule.onNodeWithText("Cancel").performClick()
  rule.onNodeWithText("0.900000 in").assertIsDisplayed()
 }
 @Test fun unitsDetailsAndRecreation() {
  rule.onNodeWithText("Settings").performClick()
  rule.onNodeWithText("mm").performClick()
  rule.onNodeWithText("Close").performClick()
  rule.onNodeWithText("50.82540 mm").assertIsDisplayed()
  rule.onNodeWithText("CALCULATED CENTER DISTANCE").performClick()
  rule.onNodeWithText("Calculated center distance\n50.82540 mm").assertIsDisplayed()
  shot("details",true)
  rule.onNodeWithText("Close").performClick()
  rule.activityRule.scenario.recreate()
  rule.onNodeWithText("50.82540 mm").assertIsDisplayed()
 }
 @Test @Config(qualifiers="w320dp-h480dp-port") fun compactViewport() {
  rule.onNodeWithText("Different sizes").performScrollTo().performClick()
  rule.onNodeWithText("Proudly made and released open source by PimaTech.org").performScrollTo().assertIsDisplayed()
  rule.onNodeWithText("Hole 2 measured Ø").performScrollTo().performClick()
  rule.onNodeWithText("Cancel").performScrollTo().performClick()
  rule.onNodeWithText("Help & formulas").performScrollTo().performClick()
  rule.onNodeWithText("Close").assertIsDisplayed()
 }
}
