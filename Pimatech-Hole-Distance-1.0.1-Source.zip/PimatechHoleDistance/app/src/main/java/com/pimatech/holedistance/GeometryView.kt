package com.pimatech.holedistance
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import com.pimatech.holedistance.engine.*
import kotlin.math.*
@Composable fun GeometryView(s:Setup,answer:Answer?,modifier:Modifier=Modifier) {
 Canvas(modifier.semantics {contentDescription="Two-hole schematic. C joins centers; outside span joins far walls; inside gap joins nearest walls. Outside at target centers using actual diameters: ${formatDimension(answer?.targetOutside,s.unit)}. Inside at target centers using actual diameters: ${formatDimension(answer?.targetInside,s.unit)}. Yellow indicates the selected span type."}) {
  val w=size.width;val h=size.height
  if(w<=0 || h<=0) return@Canvas
  val a=s.measuredA.toDouble();val b=(if(s.different) s.measuredB else s.measuredA).toDouble()
  val maxR=min(h*.19f,w*.115f)
  val r1=maxR*(a/max(a,b)).toFloat().coerceIn(.35f,1f)
  val r2=maxR*(b/max(a,b)).toFloat().coerceIn(.35f,1f)
  val x1=w*.25f;val x2=w*.75f;val y=h*.51f
  val dash=PathEffect.dashPathEffect(floatArrayOf(7.dp.toPx(),4.dp.toPx()))
  drawLine(Muted.copy(alpha=.65f),Offset(w*.06f,y),Offset(w*.94f,y),1.dp.toPx(),pathEffect=dash)
  for((x,r) in listOf(x1 to r1,x2 to r2)) {
   drawCircle(Cyan.copy(alpha=.06f),r,Offset(x,y))
   drawCircle(Cyan,r,Offset(x,y),style=Stroke(2.dp.toPx()))
   drawLine(Cyan,Offset(x-5.dp.toPx(),y),Offset(x+5.dp.toPx(),y),1.dp.toPx())
   drawLine(Cyan,Offset(x,y-5.dp.toPx()),Offset(x,y+5.dp.toPx()),1.dp.toPx())
  }
  val paint=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{textSize=11.dp.toPx();textAlign=android.graphics.Paint.Align.CENTER;typeface=android.graphics.Typeface.DEFAULT_BOLD}
  fun text(t:String,x:Float,yv:Float,color:Color) {paint.color=color.toArgb();drawContext.canvas.nativeCanvas.drawText(t,x,yv,paint)}
  fun dimension(from:Float,to:Float,yy:Float,label:String,color:Color,extensionStart:Float) {
   for(x in listOf(from,to)) drawLine(color.copy(alpha=.4f),Offset(x,extensionStart),Offset(x,yy+4.dp.toPx()),1.dp.toPx())
   drawLine(color,Offset(from,yy),Offset(to,yy),1.2.dp.toPx())
   val len=4.dp.toPx()
   drawLine(color,Offset(from,yy),Offset(from+len,yy-len/2),1.2.dp.toPx());drawLine(color,Offset(from,yy),Offset(from+len,yy+len/2),1.2.dp.toPx())
   drawLine(color,Offset(to,yy),Offset(to-len,yy-len/2),1.2.dp.toPx());drawLine(color,Offset(to,yy),Offset(to-len,yy+len/2),1.2.dp.toPx())
   paint.textSize=11.dp.toPx()
   val available=(size.width-12.dp.toPx()).coerceAtLeast(1f)
   if(paint.measureText(label)>available) paint.textSize*=available/paint.measureText(label)
   val width=paint.measureText(label)+8.dp.toPx();val mid=(from+to)/2
   drawRect(Panel,Offset(mid-width/2,yy-12.dp.toPx()),androidx.compose.ui.geometry.Size(width,14.dp.toPx()))
   text(label,mid,yy-2.dp.toPx(),color)
  }
  dimension(x1-r1,x2+r2,h*.18f,"OUTSIDE · "+formatDimension(answer?.targetOutside,s.unit),if(s.kind==SpanKind.OUTSIDE) Warn else Muted,y)
  dimension(x1+r1,x2-r2,h*.88f,"INSIDE · "+formatDimension(answer?.targetInside,s.unit),if(s.kind==SpanKind.INSIDE) Warn else Muted,y)
  dimension(x1,x2,y,"C · "+formatDimension(answer?.center,s.unit),Good,y-5.dp.toPx())
  text("1",x1,y+r1+14.dp.toPx(),Cyan);text("2",x2,y+r2+14.dp.toPx(),Cyan)
 }
}
