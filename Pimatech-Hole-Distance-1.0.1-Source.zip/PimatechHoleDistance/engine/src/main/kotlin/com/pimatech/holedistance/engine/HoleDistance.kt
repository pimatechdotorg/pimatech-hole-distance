package com.pimatech.holedistance.engine

import java.math.BigDecimal
import java.math.RoundingMode

private val TWO=BigDecimal("2")
private val FACTOR=BigDecimal("25.4")
val MAX_DIM=BigDecimal("1000000")
enum class LengthUnit(val label:String,val decimals:Int) {
 INCH("in",6), MM("mm",5);
 fun canonical(value:BigDecimal):BigDecimal=if(this==INCH) value.multiply(FACTOR) else value
 fun display(mm:BigDecimal):BigDecimal=if(this==INCH) mm.divide(FACTOR,16,RoundingMode.HALF_UP) else mm
}
enum class SpanKind { OUTSIDE, INSIDE }
data class Hole(val target:BigDecimal,val measured:BigDecimal)
data class Answer(val center:BigDecimal,val deviation:BigDecimal,val requiredSpan:BigDecimal,val nominalSpan:BigDecimal,val inside:BigDecimal,val outside:BigDecimal,val targetInside:BigDecimal,val targetOutside:BigDecimal)
object HoleDistance {
 /** All lengths use one common unit. Exact decimal radius arithmetic; no floating point. */
 fun solve(target:BigDecimal,a:Hole,b:Hole,span:BigDecimal,kind:SpanKind):Answer {
  require(target.signum()>0 && target<=MAX_DIM){"Target center distance must be greater than zero and at most 1,000,000 mm."}
  listOf(a.target,a.measured,b.target,b.measured).forEach {
   require(it.signum()>0 && it<=MAX_DIM){"All hole diameters must be greater than zero and at most 1,000,000 mm."}
  }
  require(span.signum()>=0 && span<=MAX_DIM.multiply(BigDecimal("3"))){"Measured span must be zero or greater, up to 3,000,000 mm."}
  val r=a.measured.add(b.measured).divide(TWO)
  val rn=a.target.add(b.target).divide(TWO)
  require(target>=rn){"Target diameters overlap at the target center distance."}
  require(target>=r){"Measured diameters overlap at the target center distance."}
  val center=if(kind==SpanKind.OUTSIDE) span.subtract(r) else span.add(r)
  require(center>=r){"Outside span is too small for two separate holes. Check the diameters or select Inside gap."}
  val direction=if(kind==SpanKind.OUTSIDE) 1 else -1
  return Answer(center,center.subtract(target),target.add(r.multiply(BigDecimal(direction))),target.add(rn.multiply(BigDecimal(direction))),center.subtract(r),center.add(r),target.subtract(r),target.add(r))
 }
}
fun formatDimension(mm:BigDecimal?,unit:LengthUnit,signed:Boolean=false):String {
 if(mm==null) return "—"
 val value=unit.display(mm)
 val rounded=value.setScale(unit.decimals,RoundingMode.HALF_UP)
 val sign=if(signed && value.signum()>0) "+" else ""
 if(value.signum()!=0 && rounded.signum()==0) {
  val threshold=BigDecimal.ONE.movePointLeft(unit.decimals).toPlainString()
  return (if(value.signum()<0) "−" else if(signed) "+" else "")+"<"+threshold+" "+unit.label
 }
 return sign+rounded.toPlainString()+" "+unit.label
}
