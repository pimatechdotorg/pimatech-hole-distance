package com.pimatech.holedistance

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.pimatech.holedistance.engine.*
import java.util.Locale

@Composable fun ShopDialog(title:String,onDismiss:()->Unit,content:@Composable ColumnScope.()->Unit) {
    Dialog(onDismissRequest=onDismiss) {
        Surface(color=Panel,shape=RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().heightIn(max=680.dp).padding(16.dp)) {
                Text(title,fontSize=21.sp,fontWeight=FontWeight.Bold,color=Cyan)
                Column(Modifier.weight(1f,fill=false).verticalScroll(rememberScrollState()).padding(top=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp),content=content)
                TextButton(onClick=onDismiss,modifier=Modifier.align(Alignment.End)){Text("Close")}
                Attribution()
            }
        }
    }
}

@Composable fun NumericDialog(entry:Entry,onDismiss:()->Unit,onConfirm:(java.math.BigDecimal)->Unit) {
    var text by remember(entry) { mutableStateOf(entry.initial) }
    var replace by remember(entry) { mutableStateOf(true) }
    val parsed=text.toBigDecimalOrNull()
    val error=parsed?.let(entry.validate)
    val canSave=parsed!=null && error==null
    Dialog(onDismissRequest=onDismiss) {
        Surface(color=Panel,shape=RoundedCornerShape(16.dp)) {
            Column(Modifier.heightIn(max=680.dp).padding(16.dp)) {
              Column(Modifier.weight(1f,fill=false).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text(entry.title,fontSize=19.sp,fontWeight=FontWeight.Bold)
                Text(entry.unit,color=Muted)
                Surface(color=Ink,shape=RoundedCornerShape(8.dp),modifier=Modifier.fillMaxWidth()) {
                    Text(text.ifEmpty{"—"},color=if(replace) Cyan else androidx.compose.ui.graphics.Color.White,fontSize=28.sp,modifier=Modifier.padding(12.dp),maxLines=2)
                }
                listOf(listOf("7","8","9"),listOf("4","5","6"),listOf("1","2","3"),listOf(".","0","⌫")).forEach { row ->
                    InputRow { row.forEach { key ->
                        FilledTonalButton(onClick={
                            if(key=="⌫") { text=if(replace) "" else text.dropLast(1);replace=false }
                            else { if(replace){text="";replace=false}; if(text.length<24 && (key!="." || !text.contains('.'))) text+=if(key=="." && (text.isEmpty() || text=="-")) "0." else key }
                        },modifier=Modifier.weight(1f).height(48.dp),shape=RoundedCornerShape(8.dp)) { Text(key,fontSize=22.sp) }
                    } }
                }
                InputRow {
                    TextButton(onClick={text="";replace=false},modifier=Modifier.weight(1f)){Text("Clear")}
                }
                entry.remove?.let { remove->TextButton(onClick={remove();onDismiss()},modifier=Modifier.fillMaxWidth()){Text("Remove value",color=Bad)} }
                if(!canSave) Text(error ?: "Enter a decimal dimension",color=Warn,fontSize=12.sp)
                InputRow {
                    OutlinedButton(onClick=onDismiss,modifier=Modifier.weight(1f)){Text("Cancel")}
                    Button(onClick={onConfirm(parsed!!)},enabled=canSave,modifier=Modifier.weight(1f)){Text("Save")}
                }
              }
              Attribution()
            }
        }
    }
}

