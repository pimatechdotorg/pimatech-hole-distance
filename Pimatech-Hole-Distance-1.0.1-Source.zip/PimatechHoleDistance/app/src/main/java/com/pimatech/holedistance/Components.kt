package com.pimatech.holedistance
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pimatech.holedistance.engine.*
import java.util.Locale
val Ink=Color(0xFF0B1119)
val Panel=Color(0xFF172330)
val Cyan=Color(0xFF66D7EF)
val Muted=Color(0xFFB3C2D1)
val Good=Color(0xFF8EE1A8)
val Warn=Color(0xFFFFCA75)
val Bad=Color(0xFFFF8F91)
data class Entry(val title:String,val initial:String,val unit:String,val validate:(java.math.BigDecimal)->String?={null},val remove:(()->Unit)?=null,val commit:(java.math.BigDecimal)->Unit)
@Composable fun InputRow(content:@Composable RowScope.()->Unit) { Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp),content=content) }
@Composable fun ValueButton(label:String,value:String,modifier:Modifier=Modifier,onClick:()->Unit) {
    Surface(onClick=onClick,color=Panel,shape=RoundedCornerShape(8.dp),modifier=modifier.heightIn(min=48.dp)) {
        Column(Modifier.padding(horizontal=10.dp,vertical=4.dp)) { Text(label,fontSize=10.sp,lineHeight=12.sp,color=Muted,maxLines=1,overflow=TextOverflow.Ellipsis); Text(value,fontSize=18.sp,lineHeight=22.sp,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis) }
    }
}
@Composable fun ResultCell(label:String,value:String,color:Color,modifier:Modifier,labelColor:Color=Muted) {
    Column(modifier.padding(horizontal=4.dp,vertical=1.dp)) { Text(label,color=labelColor,fontSize=9.sp,lineHeight=10.sp,maxLines=1); Text(value,color=color,fontSize=16.sp,lineHeight=20.sp,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis) }
}
@Composable fun ActionButton(title:String,modifier:Modifier,onClick:()->Unit) { OutlinedButton(onClick=onClick,modifier=modifier.heightIn(min=48.dp),shape=RoundedCornerShape(8.dp),contentPadding=PaddingValues(horizontal=8.dp,vertical=4.dp)){Text(title,fontSize=10.sp,lineHeight=12.sp,maxLines=2)} }

@Composable fun Attribution() {
    Text("Proudly made and released open source by PimaTech.org",color=Muted,fontSize=10.sp,lineHeight=12.sp,textAlign=androidx.compose.ui.text.style.TextAlign.Center,modifier=Modifier.fillMaxWidth().padding(top=4.dp,bottom=2.dp))
}
