package com.pimatech.holedistance
import android.content.Context
import com.pimatech.holedistance.engine.*
import java.math.BigDecimal

data class Setup(
 val target:BigDecimal=BigDecimal("50.8"),
 val targetA:BigDecimal=BigDecimal("12.7"),val measuredA:BigDecimal=BigDecimal("12.7254"),
 val targetB:BigDecimal=BigDecimal("12.7"),val measuredB:BigDecimal=BigDecimal("12.7254"),
 val span:BigDecimal=BigDecimal("63.5508"),
 val different:Boolean=false,val kind:SpanKind=SpanKind.OUTSIDE,val unit:LengthUnit=LengthUnit.INCH
) {
 fun answer()=HoleDistance.solve(target,Hole(targetA,measuredA),Hole(if(different) targetB else targetA,if(different) measuredB else measuredA),span,kind)
 fun linked()=copy(targetB=targetA,measuredB=measuredA,different=false)
}
class LocalStore(context:Context) {
 private val prefs=context.getSharedPreferences("hole-distance",Context.MODE_PRIVATE)
 fun load():Setup=runCatching {
  val d=Setup()
  fun read(key:String,default:BigDecimal)=prefs.getString(key,null)?.toBigDecimal()?.also{require(it>=BigDecimal.ZERO && it<=MAX_DIM.multiply(BigDecimal("3")))} ?: default
  val s=Setup(read("target",d.target),read("targetA",d.targetA),read("measuredA",d.measuredA),read("targetB",d.targetB),read("measuredB",d.measuredB),read("span",d.span),prefs.getBoolean("different",false),SpanKind.valueOf(prefs.getString("kind","OUTSIDE")!!),LengthUnit.valueOf(prefs.getString("unit","INCH")!!))
  if(s.different) s else s.linked()
 }.getOrDefault(Setup())
 fun save(s:Setup) {
  val edit=prefs.edit()
  mapOf("target" to s.target,"targetA" to s.targetA,"measuredA" to s.measuredA,"targetB" to s.targetB,"measuredB" to s.measuredB,"span" to s.span).forEach{(k,v)->edit.putString(k,v.toPlainString())}
  edit.putBoolean("different",s.different).putString("kind",s.kind.name).putString("unit",s.unit.name).apply()
 }
}
