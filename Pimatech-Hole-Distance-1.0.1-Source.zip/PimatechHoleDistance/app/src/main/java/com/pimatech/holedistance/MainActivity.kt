package com.pimatech.holedistance
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pimatech.holedistance.engine.*
import java.math.BigDecimal

class MainActivity:ComponentActivity() {
 override fun onCreate(savedInstanceState:Bundle?) {
  super.onCreate(savedInstanceState)
  val store=LocalStore(this)
  setContent { MaterialTheme(colorScheme=darkColorScheme(primary=Cyan,background=Ink,surface=Panel,onSurface=Color.White,onBackground=Color.White,secondary=Good,error=Bad)) {
   var state by remember { mutableStateOf(store.load()) }
   Calculator(state) { state=it;store.save(it) }
  } }
 }
}
@Composable fun Calculator(s:Setup,change:(Setup)->Unit) {
 var popup by remember { mutableStateOf<String?>(null) }
 var entry by remember { mutableStateOf<Entry?>(null) }
 val result=runCatching{s.answer()};val answer=result.getOrNull();val u=s.unit
 fun edit(title:String,value:BigDecimal,zero:Boolean=false,span:Boolean=false,commit:(BigDecimal)->Unit) {
  entry=Entry(title,u.display(value).stripTrailingZeros().toPlainString(),u.label,validate={
   when {
    it.signum()<0 || (!zero && it.signum()==0)->if(zero) "Use zero or greater." else "Use a value greater than zero."
    u.canonical(it)>MAX_DIM.multiply(if(span) BigDecimal("3") else BigDecimal.ONE)->"Dimension exceeds this calculator's range."
    it.stripTrailingZeros().scale()>12->"Use at most 12 decimal places."
    else->null
   }
  }){commit(u.canonical(it))}
 }
 @Composable fun DiameterRow(hole:String,ta:BigDecimal,ma:BigDecimal,onTarget:(BigDecimal)->Unit,onMeasured:(BigDecimal)->Unit) {
  InputRow {
   ValueButton("$hole target Ø",formatDimension(ta,u),Modifier.weight(1f)){edit("$hole target diameter",ta,commit=onTarget)}
   ValueButton("$hole measured Ø",formatDimension(ma,u),Modifier.weight(1f)){edit("$hole measured diameter",ma,commit=onMeasured)}
  }
 }
 Surface(color=Ink,modifier=Modifier.fillMaxSize()) {
  BoxWithConstraints(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
   val fallback=maxHeight<650.dp || androidx.compose.ui.platform.LocalDensity.current.fontScale>1.2f
   Column(Modifier.fillMaxSize().then(if(fallback) Modifier.verticalScroll(rememberScrollState()) else Modifier).padding(horizontal=12.dp,vertical=6.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
     Column(Modifier.weight(1f)) { Text("PIMATECH",color=Cyan,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=2.sp);Text("HOLE DISTANCE",fontSize=20.sp,fontWeight=FontWeight.Bold) }
     TextButton(onClick={popup="settings"}){Text(u.label.uppercase(),fontWeight=FontWeight.Bold)}
    }
    InputRow {
     listOf(false,true).forEach { different->
      OutlinedButton(onClick={if(s.different!=different) change(if(different) s.copy(different=true) else s.linked())},modifier=Modifier.weight(1f).heightIn(min=36.dp),contentPadding=PaddingValues(4.dp),shape=RoundedCornerShape(8.dp)) {
       Text((if(s.different==different) "✓ " else "")+if(different) "Different sizes" else "Same size",fontSize=12.sp)
      }
     }
    }
    Surface(color=Panel,shape=RoundedCornerShape(12.dp),modifier=Modifier.fillMaxWidth().then(if(fallback) Modifier.height(160.dp) else Modifier.weight(1f)).clickable{popup="geometry"}) {
     Column(Modifier.padding(8.dp)) {
      Text("SPANS AT TARGET CENTERS · ACTUAL Ø",color=Muted,fontSize=9.sp)
      GeometryView(s,answer,Modifier.fillMaxWidth().weight(1f))
     }
    }
    ValueButton("Target center distance · C",formatDimension(s.target,u),Modifier.fillMaxWidth()){edit("Target center distance",s.target){change(s.copy(target=it))}}
    DiameterRow(if(s.different) "Hole 1" else "Both holes",s.targetA,s.measuredA,
     {val n=s.copy(targetA=it);change(if(s.different) n else n.linked())},
     {val n=s.copy(measuredA=it);change(if(s.different) n else n.linked())})
    if(s.different) DiameterRow("Hole 2",s.targetB,s.measuredB,{change(s.copy(targetB=it))},{change(s.copy(measuredB=it))})
    InputRow {
     SpanKind.entries.forEach { kind->
      OutlinedButton(onClick={if(s.kind!=kind) change(s.copy(kind=kind,span=answer?.let{if(kind==SpanKind.OUTSIDE) it.outside else it.inside} ?: s.span))},modifier=Modifier.weight(1f).heightIn(min=36.dp),contentPadding=PaddingValues(4.dp),shape=RoundedCornerShape(8.dp)) {
       Text((if(s.kind==kind) "✓ " else "")+if(kind==SpanKind.OUTSIDE) "Outside span" else "Inside gap",fontSize=12.sp)
      }
     }
    }
    ValueButton(if(s.kind==SpanKind.OUTSIDE) "Measured outside span · M" else "Measured inside gap · M",formatDimension(s.span,u),Modifier.fillMaxWidth()){edit("Measured "+if(s.kind==SpanKind.OUTSIDE) "outside span" else "inside gap",s.span,zero=true,span=true){change(s.copy(span=it))}}
    Surface(color=Good.copy(alpha=.08f),shape=RoundedCornerShape(12.dp),modifier=Modifier.fillMaxWidth().clickable{popup="results"}) {
     Column(Modifier.padding(horizontal=12.dp,vertical=7.dp),verticalArrangement=Arrangement.spacedBy(1.dp)) {
      Text("CALCULATED CENTER DISTANCE",color=Good,fontSize=10.sp,fontWeight=FontWeight.Bold)
      Text(formatDimension(answer?.center,u),color=if(answer==null) Bad else Good,fontSize=28.sp,lineHeight=32.sp,fontWeight=FontWeight.Bold)
      if(answer!=null) {
       Text("Δ from target: "+formatDimension(answer.deviation,u,true)+if(answer.deviation.signum()>0) " · OVER" else if(answer.deviation.signum()<0) " · UNDER" else " · ON TARGET",color=if(answer.deviation.signum()==0) Good else Warn,fontSize=12.sp)
       Text("Span at target centers: "+formatDimension(answer.requiredSpan,u),color=Cyan,fontSize=11.sp)
       Text("Uses measured Ø · tap for nominal span",color=Muted,fontSize=9.sp)
      } else Text(result.exceptionOrNull()?.message ?: "Check inputs.",color=Bad,fontSize=11.sp,lineHeight=13.sp)
     }
    }
    InputRow {
     ActionButton("Help & formulas",Modifier.weight(1f)){popup="help"}
     ActionButton("Settings",Modifier.weight(1f)){popup="settings"}
     ActionButton("Reset",Modifier.weight(1f)){popup="reset"}
    }
    Attribution()
   }
  }
 }
 when(popup) {
  "geometry"->ShopDialog("Hole measurement geometry",{popup=null}) {
   GeometryView(s,answer,Modifier.fillMaxWidth().height(250.dp))
   Text("Outside and Inside show the calculated spans at the TARGET center distance, using ACTUAL measured diameters. Yellow highlights the selected span type. Green C shows the actual center distance calculated from your measured span. Diameters and contact points are schematic; do not measure the drawing.")
   Text("Outside span: far wall of Hole 1 to far wall of Hole 2. Inside gap: nearest wall of Hole 1 to nearest wall of Hole 2. Measurements must be along the line joining the hole centers.",color=Muted)
  }
  "results"->ShopDialog("Distance details",{popup=null}) {
   if(answer==null) Text(result.exceptionOrNull()?.message ?: "Check inputs.",color=Bad) else {
    Text("Calculated center distance\n"+formatDimension(answer.center,u),color=Good,fontWeight=FontWeight.Bold)
    Text("Calculated − target\n"+formatDimension(answer.deviation,u,true),color=Warn)
    Text("${if(s.kind==SpanKind.OUTSIDE) "Outside span" else "Inside gap"} at target centers, using MEASURED diameters\n"+formatDimension(answer.requiredSpan,u),color=Cyan)
    Text("Nominal ${if(s.kind==SpanKind.OUTSIDE) "outside span" else "inside gap"}, using TARGET diameters\n"+formatDimension(answer.nominalSpan,u))
    Text("Equivalent outside span: "+formatDimension(answer.outside,u)+"\nEquivalent inside gap: "+formatDimension(answer.inside,u),color=Muted)
    Text("Hole 1 diameter Δ: "+formatDimension(s.measuredA.subtract(s.targetA),u,true))
    Text("Hole 2 diameter Δ: "+formatDimension((if(s.different) s.measuredB else s.measuredA).subtract(if(s.different) s.targetB else s.targetA),u,true))
   }
  }
  "settings"->ShopDialog("Settings",{popup=null}) {
   Text("Display units · physical dimensions are preserved")
   InputRow {LengthUnit.entries.forEach{unit->OutlinedButton(onClick={change(s.copy(unit=unit))},modifier=Modifier.weight(1f)){Text((if(u==unit) "✓ " else "")+unit.label)}}}
   Text("Display: 6 decimals in inches, 5 in millimeters. Decimal entry supports up to 12 places; calculations retain stored decimal values. Display precision does not imply measurement accuracy.",color=Muted)
   Text("Inputs, units and measurement mode save on this device. No network access, accounts, ads or analytics.")
   Text("Version 1.0.1 · Native Android · MIT open source",color=Muted,fontSize=12.sp)
  }
  "help"->ShopDialog("Operator & engineering",{popup=null}) {
   Text("Enter target center distance and target / measured hole diameters. Same size applies Hole 1 values to both holes. Different sizes opens independent inputs. Returning to Same size copies Hole 1 diameters to Hole 2.")
   Text("Choose Outside span or Inside gap, then enter the measured span. Switching measurement mode converts a valid span to its equivalent, preserving the calculated center distance. Units preserve physical dimensions.")
   Text("R = (measured Ø1 + measured Ø2) / 2\nOutside: C = M − R\nInside: C = M + R\nΔ = calculated C − target C",color=Cyan)
   Text("Span at target centers uses your measured diameters: outside = target C + R; inside = target C − R. Nominal span uses the target diameters instead. Tap the result for both.")
   Text("Assumes two separate round holes with parallel axes, measured in one common plane along the line joining their centers. Off-center chords, skewed calipers, burrs, chamfers, lobing or out-of-round holes can give misleading results. Use actual hole diameters, not loose pin diameters.")
   Text("Tangent holes allow an inside gap of zero. Overlapping holes are outside this tool's model. No tolerance acceptance is inferred from the deviation; calibration, temperature and measurement uncertainty are not modeled.",color=Muted)
  }
  "reset"->ShopDialog("Reset hole distance?",{popup=null}) {
   Text("Restore the example: 2 in target centers, 0.500 in target Ø, 0.501 in measured Ø and 2.502 in outside span. Keep display units.")
   Button(onClick={change(Setup(unit=u));popup=null},modifier=Modifier.fillMaxWidth()){Text("Reset")}
  }
 }
 entry?.let{e->NumericDialog(e,{entry=null}){e.commit(it);entry=null}}
}
